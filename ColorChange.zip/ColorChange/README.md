Color Change
============

This plugin enables the printing of multicolored objects with a single extruder
by adding a pause before the selected layer/s to change the filament. 
The plugin was developed in the context of the software practical course 
Multimodal Media Madness [M3] under Prof. Dr. Jan Borchers at RWTH-Aachen.
